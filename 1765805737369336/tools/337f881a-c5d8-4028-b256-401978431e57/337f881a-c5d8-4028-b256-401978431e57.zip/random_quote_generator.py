from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission
from typing import List, Dict, Any, Optional
import random

@tool(
    name="random_quote_generator",
    description="Generates random quotes from a list",
    permission=ToolPermission.READ_ONLY
)
def random_quote_generator() -> str:
    """
    Generates random quotes from a list
    
    :returns: A random quote from the list
    """
    quotes = [
       "The best way to predict the future is to create it.",
        "Do what you can, with what you have, where you are.",
        "Success is not final, failure is not fatal: it is the courage to continue that counts.",
        "Happiness depends upon ourselves.",
        "Believe you can and you're halfway there.",
        "What lies behind us and what lies before us are tiny matters compared to what lies within us.",
        "It always seems impossible until it's done.",
        "Opportunities don't happen. You create them.",
        "Life is what happens when you're busy making other plans.",
        "Be yourself; everyone else is already taken."
    ]
    random_quote = random.choice(quotes)
    return random_quote