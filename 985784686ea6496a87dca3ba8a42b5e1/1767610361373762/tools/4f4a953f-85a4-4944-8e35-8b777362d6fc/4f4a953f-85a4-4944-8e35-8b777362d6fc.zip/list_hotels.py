from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission

@tool(permission=ToolPermission.READ_ONLY)
def list_hotels(city: str) -> dict:
    """Lists available hotels in the specified city.

    Args:
        city (str): The name of the city to search hotels in.

    Returns:
        dict: A dictionary containing a list of hotels with basic details such as
              hotel ID, name, rating, and price per night.
    """
    return {
        "city": city,
        "hotels": [
            {"id": "H101", "name": "Grand Plaza", "rating": 4.5, "price_per_night": 120},
            {"id": "H102", "name": "City Inn", "rating": 4.0, "price_per_night": 90},
            {"id": "H103", "name": "Comfort Stay", "rating": 3.8, "price_per_night": 70}
        ]
    }
