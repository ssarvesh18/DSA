import random
from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission

@tool(permission=ToolPermission.READ_ONLY)
def book_a_flight_ticket(flight_number: str, name_of_the_traveller: str, date_of_the_journey: str) -> str:
    """
        Tool to book a flight ticket provided the flight number, name of the traveller and date of the journey
        :param flight_number: Flight number
        :param name_of_the_traveller: Name of the traveller
        :param date_of_the_journey: Date of the journey in DD-MM-YYYY format
        :returns: Booking ID and Status in the format "Booking ID|Status". Example is "B12345|Booked"
    """
    return "B" + str(random.randint(50000, 70000)) + "|Booked"


if __name__ == "__main__":
    print(book_a_flight_ticket("6E 7882", "Ravi", "22-01-2024"))